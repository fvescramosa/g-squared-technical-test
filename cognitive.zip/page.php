<?php get_template_part('templates/main-template'); ?>
