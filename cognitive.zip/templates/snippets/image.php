<div class="image">
    <div class="container">
        <img src="<?php echo get_sub_field('image')['url']; ?>" alt="">
    </div>
</div>