
<div class="page-header" style="background-image: url('<?php echo get_sub_field('page_header')['url']; ?>')">
   <div class="overlay">
        <div class="container">
            <div class="page-header-content">
                <h1 class="title"><?php the_title(); ?></h1>
            </div>
        </div>
   </div>
</div>


