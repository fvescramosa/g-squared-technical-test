
<div class="desktop-menu show-for-medium" id="main-menu">
    <div class="top-bar">
        <div class="top-bar-left">
            <?php joints_top_nav(); ?>
        </div>
    </div>
</div>
<div class="mobile-menu show-for-small-only">
    <?php joints_top_nav(); ?>
</div>
